import "../../css/homepagecss/homepage.css";

const HMCategories = () => {
  return (
    <div className="home-catergories flex-col-left">
      <h3>Explore our catergories</h3>
      <ul className="flex">
        <a href="#" className="flex">
          <li>Necklace</li>
        </a>
        <a href="#" className="flex">
          <li>Rings</li>
        </a>
        <a href="#" className="flex">
          <li>Bracelets</li>
        </a>
        <a href="#" className="flex">
          <li>Necklace</li>
        </a>
        <a href="#" className="flex">
          <li>Rings</li>
        </a>
      </ul>
    </div>
  );
};

export default HMCategories;
