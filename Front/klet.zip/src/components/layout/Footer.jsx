import "../../css/layoutcss/layout.css"
const Footer = () => {
  return (
    <div className="footer">
      <h1>KLETOS</h1>
      <p>Find pieces that shimmer and radiate confidence, just like you.</p>
    </div>
  );
}

export default Footer
