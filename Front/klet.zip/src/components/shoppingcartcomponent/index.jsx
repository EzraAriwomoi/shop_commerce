import { Img } from "./Img";
import { Button } from "./Button";
import { Text } from "./Text";
import { Heading } from "./Heading";
export { Img, Button, Text, Heading };
