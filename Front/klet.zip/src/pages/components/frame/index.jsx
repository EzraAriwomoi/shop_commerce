// eslint-disable-next-line no-unused-vars
import React from "react";
import "./style.css";
import { Button } from "../../../components/shoppingcartcomponent";

export const Frame = () => {
  return (
    <a href="#"><Button className="frame">New</Button></a>
  );
};
export const Frame2 = () => {
  return (
    <a href="#"><Button className="frame2">Popular</Button></a>
  );
};