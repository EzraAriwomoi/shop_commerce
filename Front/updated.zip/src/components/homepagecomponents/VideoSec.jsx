const VideoSec = ()=>{
    return(
        <div className="home-video-sec">
            <img />
        </div>
    )
}

export default VideoSec